//
//  LayoutFundamentalApp.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

@main
struct LayoutFundamentalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
