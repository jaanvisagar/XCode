//
//  Translucent.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct Translucent: View {
    var body: some View {
        VStack{
            ZStack{
                Image("scenery")
                    .resizable()
                    .scaledToFit()
                
                    .frame(width: 400, height: 300)
                    .cornerRadius(20)
                    .padding(10)
                
                
            }
            Text("This is beautiful")
                .font(Font.largeTitle.bold())
                .foregroundStyle(Color.black)
            .background(.regularMaterial)
        }
    }
}

#Preview {
    Translucent()
}
