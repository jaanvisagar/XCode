//
//  ZStack_FoodItem.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct ZStack_FoodItem: View {
    var body: some View {
        ZStack {
            Image("biryani")
                .resizable()
                .scaledToFit()
                .frame(width: 350, height: 450)
            
                Text("Veg-Biryani")
                .padding(4)
                    .font(.title3)
                    .bold()
                    .background(.green)
                    .clipShape(Capsule())
                    .frame(width: 350, height:50)
                    .cornerRadius(20)
                    .offset(x: -120, y: -90)
            
//            Image("biryani")
//                .clipShape(RoundedRectangle(cornerRadius: 20))
        }
      
            
    }
}

#Preview {
    ZStack_FoodItem()
}
