//
//  NestedView_Task2.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct NestedView_Task2: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 20)
            .foregroundStyle(Color.blue.opacity(0.6))
            .frame(width: 380, height: 500)
            .overlay(
        VStack{
            ZStack{
                Image("jaanvi")
                    
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 250)
                    .clipShape(.circle)
                
                
                Image("badge")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 40, height: 50)
                    .clipShape(.circle)
                    .offset(x: 60, y: -50)
                    
           }
            Text("Jaanvi Sagar")
                .font(Font.largeTitle.bold())
            Text("23SCSE1420169")
                .font(.title2)
            
            HStack{
                Text("Expertise")
                    .font(Font.title.bold())
                Text("Java")
                    .padding(5)
                    .background(Color.blue.opacity(0.5))
                    .foregroundColor(.white)
                    .cornerRadius(5)
                Text("Swift")
                    .padding(5)
                    .background(Color.blue.opacity(0.5))
                    .foregroundColor(.white)
                    .cornerRadius(5)
                Text("Python")
                    .padding(5)
                    .background(Color.blue.opacity(0.5))
                    .foregroundColor(.white)
                    .cornerRadius(5)
                
            }
            .padding()
            //.background(.blue.opacity(0.2))
            .cornerRadius(20)
            ZStack{
                Button(""){}
                    .frame(width: 150, height: 30)
                    .foregroundStyle(Color.white)
                    .padding(10)
                    .background(.blue.opacity(0.8))
                    .clipShape(Capsule())
                HStack{
                    Image(systemName: "phone.fill")
                        .foregroundStyle(Color.white)
                    Text("Contact")
                        .foregroundStyle(Color.white)
                }
            }
        }
        
        
        )
    }
}

#Preview {
    NestedView_Task2()
}
