//
//  ZStack_profile_Badge.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct ZStack_profile_Badge: View {
    var body: some View {
        ZStack{
            Image("jaanvi")
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 300)
                .clipShape(.circle)
            
            Image(systemName: "trophy.circle")
                .font(.system(size: 50))
                .foregroundColor(.white)
                .background(.black)
                .clipShape(Circle())
                
                .offset(x: -90, y: 40)
            
            Image(systemName: "star.hexagon")
                .font(.system(size: 50))
                .foregroundColor(.white)
                .background(.black)
                .clipShape(Circle())
                
                .offset(x: -50, y: 80)
            
            Image("badge")
                .resizable()
                .scaledToFill()
                .frame(width: 50, height: 50)
                .background(Color.white)
                .clipShape(.circle)
                .offset(x: -5, y:110)
                
        }
    }
}

#Preview {
    ZStack_profile_Badge()
}
