//
//  HStack_profile.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct HStack_profile: View {
    var body: some View {
        HStack{
                    Image("jaanvi")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 250)
                        .clipShape(Circle())
                    Text("Jaanvi Sagar")
                        .font(Font.title.bold())
        
                }
                .padding()
                .background(.green.opacity(0.2))
            }
    
}

#Preview {
    HStack_profile()
}
