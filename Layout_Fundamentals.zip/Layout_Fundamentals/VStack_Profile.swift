//
//  VStack_Profile.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct VStack_Profile: View {
    var body: some View {
        VStack{
                    Image("jaanvi")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 250)
                        .clipShape(Circle())
                    Text("Jaanvi Sagar")
                        .font(Font.largeTitle.bold())
                    Text("23SCSE1420169")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    Text("jhwbdjhvquedvcueqvdcvdhvchhsvdhv")
                }
                .padding()
                .background(.green.opacity(0.2))
            
    }
}

#Preview {
    VStack_Profile()
}
