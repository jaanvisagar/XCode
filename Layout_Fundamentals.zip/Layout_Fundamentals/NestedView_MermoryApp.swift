//
//  NestedView_MermoryApp.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct NestedView_MermoryApp: View {
    var body: some View {
        VStack{
            ZStack{
                Image("scenery")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth:.infinity)
                    .frame(height: 240)
                    .clipped()
                
                Image(systemName: "heart.fill")
                    .imageScale(.large)
                    .foregroundStyle(Color.orange)
                    .padding()
                    .background(.yellow)
                    
                    .clipShape(Circle())
                    .offset(x: 160, y: -80)
            }
            VStack(alignment: .leading){
                HStack{
                    Text("This View is Beautiful")
                        .font(.headline)
                        .bold(true)
                    Label("21 July 2025", systemImage: "calendar")
                        .font(.footnote)
                        .foregroundStyle(Color.secondary)
                    
                }
                Text("This is a image of a beautiful scenery somewhere in the heaven.")
                    
            }
            .padding()

        }
        .background(.blue)
        .cornerRadius(20)
       
            }
}

#Preview {
    NestedView_MermoryApp()
}
