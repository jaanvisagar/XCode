//
//  Translucent.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct Translucent: View {
    var body: some View {
        VStack{
            ZStack{
                Image("tyu")
                    .resizable()
                    .scaledToFit()
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                
                    .frame(width: 380)
                    
                    .cornerRadius(20)
                    
                    
                Text("This is beautiful")
                    .foregroundStyle(.black)
                    .font(.largeTitle.bold())
                    .foregroundStyle(.primary)
                    .frame(width: 380)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(.regularMaterial.opacity(0.5), in: Rectangle())
                    .cornerRadius(20)
                    .offset(y: 68)
                   
                
            }
            
        }
    }
}

#Preview {
    Translucent()
}
