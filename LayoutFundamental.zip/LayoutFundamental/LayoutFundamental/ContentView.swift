//
//  ContentView.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
                VStack(alignment: .leading, spacing: 2) {
        
                    Image(systemName: "birthday.cake")
                        .imageScale(.large)
                        .foregroundStyle(.tint)
                    Text("Biryani!")
                    Text("A delicious Indian dish!")
        
                
            }
        
    
        

        
        
    }
}
    

#Preview {
    ContentView()
}
