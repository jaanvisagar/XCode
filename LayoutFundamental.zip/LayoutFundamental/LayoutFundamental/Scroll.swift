//
//  Scroll.swift
//  LayoutFundamental
//
//  Created by GU on 20/12/25.
//

//import SwiftUI
//
//struct Scroll: View {
//    var body: some View {
//        ScrollView (.horizontal, showsIndicators: false){
//            HStack{
//                ForEach(1..<101) { i in
//                    Text("Item no.\(i)")
//                        .bold()
//                        .padding()
//                        .background(.orange)
//                }
//            }
//        }
//    }
//}
//
//#Preview {
//    Scroll()
//}

import SwiftUI

struct Scroll: View {
    var body: some View {
        ScrollView ( showsIndicators: false
        ){
            VStack{
                ForEach(1..<101) { i in
                    Text("Item no.\(i)")
                        .bold()
                        .padding()
                        .background(.orange)
                }
            }
        }
    }
}

#Preview {
    Scroll()
}
