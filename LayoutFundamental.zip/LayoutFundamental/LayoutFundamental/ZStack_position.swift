//
//  ZStack_position.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct ZStack_position: View {
    var body: some View {
        ZStack{
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.blue.opacity(0.5))
                .frame(width: 250, height:250)
                .zIndex(-1)
            Image(systemName: "star")
                .foregroundStyle(.white)
                .font(.system(size: 100))
                .bold()
                .zIndex(3)
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.red)
                .frame(width: 150, height:150)
                .zIndex(-2)
        }
    }
}

#Preview {
    ZStack_position()
}
