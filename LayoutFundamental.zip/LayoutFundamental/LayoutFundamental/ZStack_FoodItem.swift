//
//  ZStack_FoodItem.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct ZStack_FoodItem: View {
    var body: some View {
        ZStack {
            Image("biryani")
                .resizable()
                .scaledToFit()
                .frame(width: 350, height: 550)
            
                Text("NOn-Veg-Biryani")
                .padding(4)
                    .font(.title3)
                    .bold()
                    .background(.red)
                    .clipShape(Rectangle())
                    .cornerRadius(5)
                    .frame(width: 350, height:50)
                    .cornerRadius(20)
                    .offset(x: -93, y: -135)
                    
            
//            Image("biryani")
//                .clipShape(RoundedRectangle(cornerRadius: 20))
        }
        .frame(width: 350, height: 300)
        .border(Color.black)
      
            
    }
}

#Preview {
    ZStack_FoodItem()
}
