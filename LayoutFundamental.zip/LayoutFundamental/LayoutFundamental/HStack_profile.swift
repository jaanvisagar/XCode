//
//  HStack_profile.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct HStack_profile: View {
    var body: some View {
        HStack{
                    Image("jaanvi")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100, height: 200, alignment: .leading)
                        .clipShape(Circle())
                    Text("Jaanvi Sagar")
                        .font(Font.title.bold())
        
                }
                .padding()
                .frame(width: 350, height: 150)
                .background(.green.opacity(0.5))
                .cornerRadius(20)
                
            }
       
    
}

#Preview {
    HStack_profile()
}
