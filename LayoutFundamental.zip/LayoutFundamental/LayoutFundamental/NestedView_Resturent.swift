//
//  NestedView_Resturent.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct NestedView_Resturent: View {
    var body: some View {
        
        VStack{
            ZStack{
                Image("Thali")
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth:.infinity)
                    .frame(width:390,height: 400)
                    .clipped()
                
                Image("veg")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50, height: 100)
                    .offset(x: 80, y: 240)
            }
            VStack(alignment: .leading){
                Text("Preimium Tali")
                    .font(.largeTitle)
                    .bold(true)
                HStack{
                    Text("Rs. 500")
                        .font(.title)
                        .foregroundStyle(Color.primary)
                    Spacer(minLength: 20)
                    ZStack{
                        
                        Button(""){}
                        HStack{
                            Image(systemName: "cart.fill")
                                .foregroundStyle(Color.white)
                            Text("Add to Cart")
                                .foregroundStyle(Color.white)
                        }                 .frame(width: 150, height: 30)
                            
                            .foregroundStyle(Color.white)
                            .padding(10)
                            .background(.blue.opacity(0.8))
                            .clipShape(Capsule())
                        
                        HStack{
                            Image(systemName: "cart.fill")
                                .foregroundStyle(Color.white)
                            Text("Add to Cart")
                                .foregroundStyle(Color.white)
                        }
                        
                    }
                }
                
                HStack{
                    
                    
                    Image(systemName: "star.fill")
                    .foregroundStyle(.orange)
                    Image(systemName: "star.fill")
                        .foregroundStyle(.orange)
                    Image(systemName: "star.fill")
                        .foregroundStyle(.orange)
                    Image(systemName: "star.fill")
                        .foregroundStyle(.orange)
                    Image(systemName: "star.fill")
                        .foregroundStyle(.gray)
                    
                    
                }
                .padding(5)
                Text("This is a Veg-Tali with 100g of vegetables and 100g of dal and roti.")
                
            }
            .padding()
            
        }
        .frame(width:390, height: 700)
        .background(.gray.opacity(0.4))
        .cornerRadius(30)
        
    }
}
    

#Preview {
    NestedView_Resturent()
}
