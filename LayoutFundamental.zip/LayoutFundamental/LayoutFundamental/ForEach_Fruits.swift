//
//  ForEach_Fruits.swift
//  LayoutFundamental
//
//  Created by GU on 20/12/25.
//

import SwiftUI

struct ForEach_Fruits: View {
    var fruits =  ["Apple", "Banana", "Mango", "Orange", "Grapes"]
    var body: some View {
        ForEach(fruits, id: \.self) { fruit in
            Text(fruit)
                .font(.largeTitle)
                .bold()
        }
        .padding(40)
        .frame(width: 300)
        .background(.teal)
        .cornerRadius(20)
        
    }
}

#Preview {
    ForEach_Fruits()
}
