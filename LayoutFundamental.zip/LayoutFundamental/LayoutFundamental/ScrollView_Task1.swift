//
//  ScrollView_Task1.swift
//  LayoutFundamental
//
//  Created by GU on 20/12/25.
//

import SwiftUI
struct ToDoTask: Identifiable {
    var id = UUID()
    var title: String
    var discription: String
    
}

struct ScrollView_Task1: View {
   @State var tasks = [ToDoTask(title: "Title", discription: "This is the discription for the to do list and the title is very long so that it will be displayed in multiple lines.")]
    var body: some View {
        ZStack (alignment: .bottom){
            ScrollView{
                ForEach(tasks){ task in
                    VStack(alignment: .leading){
                        Text(task.title)
                            .font(.largeTitle)
                        Text(task.discription)
                            .font(.body)
                    }
                    .padding()
                    .background(.orange.opacity(0.5))
                }
                }
            
            Button {
                tasks.append(ToDoTask(title: "Title", discription: "This is the discription for the to do list and the title is very long so that it will be displayed in multiple lines."))
                
                
            } label: {
                Image(systemName: "plus")
                    .font(.title)
                    .bold()
                    .foregroundColor(.gray)
//                    .padding(20)
//                    .background(.orange.opacity(0.5))
//                    .clipShape(Capsule())
            }
            .padding(20)
            .background(.orange.opacity(0.5))
            .clipShape(Capsule())
            
                
            
        }
    }
}

#Preview {
    ScrollView_Task1()
}
