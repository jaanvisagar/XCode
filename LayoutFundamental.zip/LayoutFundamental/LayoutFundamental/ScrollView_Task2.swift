//
//  ScrollView_Task2.swift
//  LayoutFundamental
//
//  Created by GU on 20/12/25.
//

import SwiftUI

struct ScrollView_Task2: View {
    var body: some View {
        Text("Resturents")
            .bold()
            .font(.largeTitle)
        ScrollView(){
            VStack(alignment: .leading){
                ForEach(1..<6){i in
                    Text(" Resturent \(i)")
                        .font(.title)
                        .padding()
                    ScrollView(.horizontal) {
                        HStack{
                            ForEach(1..<40){j in
                                Text("Dish \(j)")
                                    .frame(width:200, height: 150)
                                    .background(.purple.opacity(0.3))
                                    .cornerRadius(10)
                                
                            }
                            
                        }
                    }
                }
            }
            
        }
        .padding()
    }
}

#Preview {
    ScrollView_Task2()
}
