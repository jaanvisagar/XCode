//
//  HStack_Profilex5.swift
//  LayoutFundamental
//
//  Created by GU on 20/12/25.
//

import SwiftUI

struct Student: Identifiable {
    var id = UUID()
    var image: String
    var name: String
}

struct ProfileView: View {
    var student: Student
    var body: some View {
        VStack(){
            HStack(spacing: 20){
                Image(student.image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50, height: 80)
                    .clipShape(Circle())
                
                Text(student.name)
                    .font(.title)
                Spacer()
                
            }
            .padding()
            .background(.mint.opacity(0.5))
    }
}
    
}

struct HStack_Profilex5: View {
    var student = [Student(image: "jaanvi", name: "Jaanvi Sagar"),
        Student(image: "Thali", name: "Kaushiki Rai"),
    Student(image: "biryani", name: "Parth Kumar"),
    Student(image: "jaanvi", name: "Priyanshu Kr."),
    Student(image: "jaanvi", name: "Rishika")]
    var body: some View {
//        ProfileView()
//        ProfileView()
//        ProfileView()
//        ProfileView()
//        ProfileView()
        // or
        
        VStack{
            ForEach( student) { student in
                ProfileView(student: student)
            }
        }
    }
}

#Preview {
    HStack_Profilex5()
}
