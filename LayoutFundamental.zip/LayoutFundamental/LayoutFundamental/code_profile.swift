//
//  code_profile.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct code_profile: View {
    var body: some View {
        HStack{
            Text("Expertise")
                .font(Font.title.bold())
            Text("Java")
                .padding(5)
                .background(Color.blue.opacity(0.5))
                .foregroundColor(.white)
                .cornerRadius(5)
            Text("Swift")
                .padding(5)
                .background(Color.blue.opacity(0.5))
                .foregroundColor(.white)
                .cornerRadius(5)
            Text("Python")
                .padding(5)
                .background(Color.blue.opacity(0.5))
                .foregroundColor(.white)
                .cornerRadius(5)
            
        }
        .padding()
        .background(.blue.opacity(0.2))
        .cornerRadius(20)
    }
}

#Preview {
    code_profile()
}
