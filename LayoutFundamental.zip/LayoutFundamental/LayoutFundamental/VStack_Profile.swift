//
//  VStack_Profile.swift
//  LayoutFundamental
//
//  Created by GU on 12/12/25.
//

import SwiftUI

struct VStack_Profile: View {
    var body: some View {
        VStack{
                    Image("jaanvi")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 190, height: 250)
                        .clipShape(Circle())
                    Text("Jaanvi Sagar")
                        .font(Font.largeTitle.bold())
                    Text("23SCSE1420169")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                    Text("Hi Everyone, I'm a 23 year old student from Galgotias University. I'm a Computer Science Engineer Student.")
                }
                .padding()
                .background(.green.opacity(0.5))
                .cornerRadius(20)
            
    }
}

#Preview {
    VStack_Profile()
}
