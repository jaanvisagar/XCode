//
//  ForEach_Task1.swift
//  LayoutFundamental
//
//  Created by GU on 20/12/25.
//

import SwiftUI

struct ForEach_Task1: View {
    @State private var friends: [String] = ["James", "Raj", "Pavan", "Shubham"]
    var colors: [Color] = [.red, .blue, .yellow, .green, .orange, .purple, .pink, .gray]
    var body: some View {
        VStack{
            ForEach(friends, id: \.self) { friend in
                Text(friend)
                    .font(Font.largeTitle)
                
                
            }
            
            Button("Add Friend"){
                friends.append("Luke")
                
            }
            .buttonStyle(.borderedProminent)
            
            .padding(10)
        }
        .padding(20)
        .background(colors.randomElement())
        .cornerRadius(20)
        .frame(maxWidth: .infinity)
        
    }
}

#Preview {
    ForEach_Task1()
}
