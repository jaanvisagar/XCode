//
//  ContentView.swift
//  Messages
//
//  Created by Probeer on 08/01/26.
//

import SwiftUI

struct ContentView: View {
    @State private var messages: [Message] = DataModel.messages.sorted{
        $0.timestamp > $1.timestamp
    }
        
//        func sortedMessages() {
//            messages.sort{
//                if $0.timestamp == $1.timestamp {
//                    return $0.id < $1.id
//                }
//                return $0.timestamp > $1.timestamp
//            }
//        }
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Messages")
                .font(.largeTitle)
                .bold()
                .padding()
            List{
                ForEach($messages) { $message in
                    MessageRowView(message: message)
                        .swipeActions(edge: .leading) {
                            Button {
                                message.isRead.toggle()
                            } label: {
                                Image(systemName: message.isRead ? "message.badge.fill" : "checkmark.message.fill")
                            }
                            .tint(.accentColor)
                        }
                        .swipeActions(edge: .trailing){
                            Button(role: .destructive) {
                                guard let index = messages.firstIndex(where: {$0.id == message.id}) else {
                                    return
                                }
                                messages.remove(at: index)
                            } label: {
                                Image(systemName: "trash")
                            }
                            Button {
                                message.isAlertHidden.toggle()
                                print(message.isAlertHidden)
                            } label: {
                                Image(systemName: "bell.fill")
                                    .symbolVariant(message.isAlertHidden ? .none : .slash)
                                
                            }
                            .tint(.indigo)
                            
                            
                        }
                        .contextMenu {
                            Button {
                                message.isPinned.toggle()
                            } label:{
                                Label(message.isPinned ? "UnPin" : "Pin" , systemImage: message.isPinned ? "pin.slash" : "pin")
                                
                            }
                            
                        }
                }
                .listStyle(.plain)
                .onChange(of: messages) { messages.sort {
                    if $0.isPinned != $1.isPinned {
                        return $0.isPinned
                    }
                    return $0.timestamp > $1.timestamp
                }
                    
                }
                
            }
        }
    }
}

#Preview {
    ContentView()
}
