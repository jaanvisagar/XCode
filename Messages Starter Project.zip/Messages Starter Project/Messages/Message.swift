//
//  Message.swift
//  Messages
//
//  Created by Probeer on 08/01/26.
//

import Foundation

struct Contact: Identifiable, Equatable{
    var id = UUID()
    var name: String
    var image: String
    static func == (lhs: Contact, rhs: Contact) -> Bool {
        lhs.id == rhs.id &&
        lhs.name == rhs.name &&
        lhs.image == rhs.image
    }
}

struct Message: Identifiable , Equatable{
    
    var id = UUID()
    var contact: Contact
    var content: String
    var timestamp: Date
    var isPinned: Bool = true
    var isRead: Bool = false
    var isAlertHidden: Bool = true
    
    static func == (lhs: Message, rhs: Message) -> Bool {
        lhs.id == rhs.id &&
        lhs.isPinned == rhs.isPinned &&
        lhs.isRead == rhs.isRead &&
        lhs.isAlertHidden == rhs.isAlertHidden
    }
}
