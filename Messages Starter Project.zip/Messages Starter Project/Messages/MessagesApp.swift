//
//  MessagesApp.swift
//  Messages
//
//  Created by Probeer on 08/01/26.
//

import SwiftUI

@main
struct MessagesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
