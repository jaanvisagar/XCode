//
//  SwipAction.swift
//  Messages
//
//  Created by GU on 09/01/26.
//

import SwiftUI

struct SwipAction: View {
    
    @State private var messages: [Message] = DataModel.messages
    var body: some View {
        List{
            ForEach($messages) {$message in
            MessageRowView(message: message)
                    .swipeActions(edge: .leading) {
                        Button {
                            message.isRead.toggle()
                        } label: {
                            Image(systemName: message.isRead ? "message.badge.fill" : "checkmark.message.fill")
                        }
                        .tint(.accentColor)
                    }
            }
            .swipeActions(edge: .trailing){
                Button(role: .destructive){
                    
                    
                } label: {
                    Image(systemName: "trash")
                }
                Button {
                    
                } label: {
                    Image(systemName: "bell.slash")
                }
                .tint(.indigo)
                
                
            }
            
            
        }
    }
    
}

#Preview {
    SwipAction()
}
