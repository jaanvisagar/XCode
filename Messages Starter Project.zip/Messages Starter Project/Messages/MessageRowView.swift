//
//  MessageRowView.swift
//  Messages
//
//  Created by GU on 09/01/26.
//

import SwiftUI

struct MessageRowView: View {
    var message: Message
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Circle()
                    .frame(width: 10, height: 10)
                    .foregroundColor(message.isRead ? .clear : .blue)
                Image(message.contact.image)
                    .resizable()
                    .frame(width: 60, height: 60)
                    .cornerRadius(15)
                
                
                
                VStack (alignment: .leading){
                    HStack {
                        Text(message.contact.name)
                            .font(.headline)
                        Spacer()
                        
                        Text(message.timestamp.formatted(date: .abbreviated, time: .omitted))
                            .padding(5)
                    }
                    
                    
                    
                    HStack {
                        Text(message.content)
                            .font(.subheadline)
                        Spacer()
                        
                        Image(systemName:  "bell.slash")
                            .foregroundStyle(message.isAlertHidden ? .blue : .clear)
                        
                        
                        Image(systemName:  "pin")
                            .foregroundStyle(message.isPinned ? .blue : .clear)
                        
                    }
                    
                }
                
            }
            
        }
        
    }
}

#Preview {
    MessageRowView(message: DataModel.messages[0])
}
