//
//  SwipToDelete.swift
//  Messages
//
//  Created by GU on 09/01/26.
//

import SwiftUI

struct SwapToDelete: View {
    @State private var messages: [Message] = DataModel.messages
    var body: some View {
        List{
            ForEach(messages) {message in
            MessageRowView(message: message)
            }
            .onDelete(perform: deleteMessages)
        }
    }
    func deleteMessages(at offsets: IndexSet) {
        messages.remove(atOffsets: offsets)
    }
}

#Preview {
    SwapToDelete()
}
