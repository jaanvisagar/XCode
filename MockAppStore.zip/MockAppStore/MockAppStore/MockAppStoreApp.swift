//
//  MockAppStoreApp.swift
//  MockAppStore
//
//  Created by GU on 20/12/25.
//

import SwiftUI

@main
struct MockAppStoreApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
