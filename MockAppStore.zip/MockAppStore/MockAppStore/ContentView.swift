//
//  ContentView.swift
//  MockAppStore
//
//  Created by GU on 20/12/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        ScrollView {
            VStack (alignment:.leading){
                HStack(){
                    Text("Apps")
                        .font(.largeTitle)
                        .bold()
                    Spacer()
                    
                    Image("Moon")
                        .resizable()
                        //.scaledToFit()
                        .frame(width: 50, height: 50)
                        .border(Color.black)
                        .clipShape(.circle)
                        
                    
                }
              
              
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack{
                        ForEach (1..<10) { i in
                            Label("Category",
                            systemImage: "\(i).circle.fill")
                            .padding(5)
                            .background(.secondary)
                            .clipShape(Capsule())
                        }
                        
                    }
                }
                Spacer(minLength: 20)
                
                VStack {
                    ScrollView(.horizontal, showsIndicators: false) {
                        
                        HStack {
                            ForEach (1..<11) { _ in
                                VStack(alignment: .leading) {
                                    Text("Context Text")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                    Text("Announcement title which can be very long")
                                        .font(.title)
                                        .bold()
                                        .frame (width:380 ,alignment: .init(horizontal: .leading, vertical: .center))
                                        
                                        
                                    ZStack{
                                        Rectangle()
                                            .fill(Color.blue)
                                            .frame(width: 370)
                                            .frame(height: 250)
                                            .cornerRadius(20)
                                        Image("Moon")
                                            .resizable()
                                            .frame(width: 100, height: 100)
                                            .cornerRadius(20)
                                    }
                                }
                            }
                        }
                        
                        
                    }
                }
               Spacer(minLength: 20)
                HStack{
                    Text("Top App this week")
                        .font(.title)
                        .bold()
                    
                    Image(systemName: "greaterthan")
                        .font(.title2)
                        .foregroundColor(.blue.opacity(0.7))
                }
                
                VStack {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach (1..<20) { _ in
                                HStack{
                                    Image("Moon")
                                        .resizable()
                                        .frame(width: 70, height: 70)
                                        .cornerRadius(20)
                                    VStack(alignment: .leading){
                                        Text("App Name")
                                            .font(.headline)
                                        Text("Discription of the app")
                                    }
                                    Spacer(minLength: 30)
                                    Button("Get"){
                                        
                                    }
                                    .buttonStyle(.borderedProminent)
                                    .padding(20)
                                }
                            }
                        }
                    }
                }
                Spacer(minLength: 20)
                HStack{
                    Text("Browse Categories")
                        .font(.title)
                        .bold()
                    
                    Image(systemName: "greaterthan")
                        .font(.title2)
                        .foregroundColor(.blue.opacity(0.7))
                }
                Spacer(minLength: 20)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach (1..<20) { _ in
                            HStack(){
                                ZStack{
                                    RoundedRectangle(cornerRadius: 20)
                                        .frame(width: 250, height: 150)
                                        .foregroundStyle(.yellow)
                                    RoundedRectangle(cornerRadius: 10)
                                        .frame(width: 50, height: 50)
                                        .foregroundStyle(.black)
                                        .offset(x: 90, y: -40)
                                    Text("Category")
                                        .foregroundStyle(.white)
                                        .font(.title)
                                        .bold()
                                        .offset(x:-50, y: 40)
                                    
                                }
                            }
                        }
                    }
                }
                Spacer(minLength: 20)
                Text("Quick Links")
                    .font(.title)
                    .bold()
                
                VStack{
                    ForEach (1..<20) { i in
                        Text("Link \(i)")
                            .font(.title2)
                    }
                    .padding(10)
                }
                
                }
        }
        .padding()
       
    }
}

#Preview {
    ContentView()
}
